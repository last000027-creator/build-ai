# AI Developer V1

A GitHub-ready starter for a voice-controlled AI coding agent.

## What V1 does

- Android app provides a voice-command UI.
- Backend exposes an agent API.
- The agent receives commands such as:
  - "Add a floating button"
  - "Change the app theme"
  - "Fix this error"
- GitHub Actions is included for automated Android builds.
- Project changes are designed to be reviewed/applied through a controlled workspace.

## Important

V1 is an architecture/starter, not a fully autonomous production coding agent. Configure an AI provider and a target repository/workspace before enabling real code modifications.

## Structure

- `android/` - Android controller app
- `agent-server/` - Python FastAPI agent backend
- `.github/workflows/build-apk.yml` - APK build workflow
- `agent-server/workspace/` - safe workspace for target-project operations

## GitHub setup

1. Create a new GitHub repository.
2. Upload the contents of this ZIP.
3. Push/commit the files.
4. Add required secrets for your chosen AI provider when you connect the real model.
5. Run the `Build APK` GitHub Action.

## Local backend

```bash
cd agent-server
python -m venv .venv
# activate the environment
pip install -r requirements.txt
uvicorn app:app --reload --host 0.0.0.0 --port 8000
```

The Android app currently uses a configurable backend URL in `BuildConfig`.
