from fastapi import FastAPI
from pydantic import BaseModel
from pathlib import Path
from datetime import datetime
import uuid

app = FastAPI(title="AI Developer Agent V1", version="1.0.0")

WORKSPACE = Path(__file__).parent / "workspace"
WORKSPACE.mkdir(exist_ok=True)

class CommandRequest(BaseModel):
    command: str
    project_path: str | None = None

class CommandResponse(BaseModel):
    job_id: str
    status: str
    message: str
    next_step: str

@app.get("/health")
def health():
    return {"status": "ok", "service": "ai-developer-agent-v1"}

@app.post("/agent/command", response_model=CommandResponse)
def command(req: CommandRequest):
    job_id = str(uuid.uuid4())
    command = req.command.strip()

    # V1 intentionally creates a plan instead of silently modifying arbitrary files.
    plan_file = WORKSPACE / f"{job_id}.plan.txt"
    plan_file.write_text(
        f"Created: {datetime.utcnow().isoformat()}Z\n"
        f"Command: {command}\n"
        f"Project: {req.project_path or '(not specified)'}\n\n"
        "Planned workflow:\n"
        "1. Inspect target project.\n"
        "2. Identify files relevant to the request.\n"
        "3. Generate a minimal patch.\n"
        "4. Validate the patch.\n"
        "5. Build and test.\n"
        "6. Create an APK artifact.\n"
        "7. Keep a rollback point.\n"
    )

    return CommandResponse(
        job_id=job_id,
        status="planned",
        message=f"Command received: {command}",
        next_step="Connect an AI provider and target Git repository to execute the generated plan."
    )
